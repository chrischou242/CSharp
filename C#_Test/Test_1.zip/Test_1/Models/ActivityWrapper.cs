using System.Collections.Generic;

namespace Test_1.Models
{
    public class ActivityWrapper
    {
        public User LoggedUser {get;set;}
        public List<Activityy> AllActivities {get;set;}
    }
}