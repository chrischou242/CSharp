using System.Collections.Generic;

namespace Test_1.Models
{
    public class DetailWrapper
    {
        public User LoggedUser {get;set;}
        public Activityy Activities {get;set;}
    }
}