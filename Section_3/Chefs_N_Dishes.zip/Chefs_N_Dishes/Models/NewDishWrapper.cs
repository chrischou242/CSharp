using System.Collections.Generic;


namespace Chefs_N_Dishes.Models
{
    public class NewDishWrapper
    {
        public Dish Form{get;set;}

        public List<Chef> AllChefs{get;set;}
    }
}